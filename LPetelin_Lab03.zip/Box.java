
public class Box extends Rectangle {
	private int height;
	
	public Box(){
		super();
		height = 15;
	}
	public Box(int newHeight){
		super();
		height = newHeight;
	}
	public void setHeight(int newHeight){
		height = newHeight;
	}
	public int getHeight(int newHeight){
		return height;
	}
	public int area(){
		return ((width * length) * 2) + (width * height) * 2 +(length * height) * 2;
	}
	public int volume(){
		return (length * width * height);
	}
	public String toString(){
		
	return super.toString() + 
			"\n Height: " + height; 

	}
}
