
public class Circle extends PointABS {
	private int radius;
	
	public Circle(){
		super();
		setRadius(15);
	}
	public Circle(int newRadius){
		super();
		setRadius(newRadius);
	}
	public void setRadius(int newRadius){
		radius = newRadius;
	}
	public int getRadius(int newRadius){
		return radius;
	}
	public double area(){
		return (3.15 * getRadius() * getRadius());
	}
	
	public String toString(){
	return super.toString() + 
			"\n Radius: " + getRadius(); 
	
	}
	public int getRadius() {
		return radius;
	}
}
