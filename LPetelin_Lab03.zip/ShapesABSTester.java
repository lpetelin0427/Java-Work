
public class ShapesABSTester {

	public static void main(String[] args) {
		System.out.println("Luke Petelin \nLab 03 \n9/16/2017");
		PointABS[] myShapes = new PointABS[4];
		
		myShapes[0] = new Rectangle(10, 20);
		myShapes[1] = new Box(30);
		myShapes[2] = new Circle(40);
		myShapes[3] = new Cylinder(50);
		int objectCounter = 0;
		for (PointABS point: myShapes){
			 if (point instanceof Box){
				System.out.println("******************************************");
				System.out.println("Object " + objectCounter + " is a Box");
				System.out.println(myShapes[1].toString());
				objectCounter++;
			}
			 else if (point instanceof Rectangle){
				System.out.println("******************************************");
				System.out.println("Object " + objectCounter + " is a Rectangle");
				System.out.println(myShapes[0].toString());
				objectCounter++;
			}

			else if (point instanceof Cylinder){
				System.out.println("******************************************");
				System.out.println("Object " + objectCounter + " is a Cylinder");
				System.out.println(myShapes[3].toString());
				objectCounter++;
			}
			else{
				System.out.println("******************************************");
				System.out.println("Object " + objectCounter + " is a Circle");
				System.out.println(myShapes[2].toString());
				objectCounter++;
			}
			
	}


	}
}
