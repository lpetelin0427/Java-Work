
public class Cylinder extends Circle{
	private int height;
	
	public Cylinder(){
		super();
		height = 15;
	}
	public Cylinder(int newHeight){
		super();
		height = newHeight;
	}
	public void setHeight(int newHeight){
		height = newHeight;
	}
	public int getHeight(int newHeight){
		return height;
	}
	public double area(){
		return (2 * 3.14 * getRadius() * getRadius() + 2 * 3.14 * getRadius() * height);
	}
	public double volume(){
		return (3.14 * getRadius() * getRadius() * height);
	}
	public String toString(){
	return super.toString() + 
			"\n Height: " + height; 
	
	}
}
