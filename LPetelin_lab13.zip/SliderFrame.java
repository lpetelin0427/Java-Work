   // Fig. 22.3: SliderFrame.java
   // Using JSliders to size an oval.
   import java.awt.BorderLayout;
   import java.awt.Color;
   import javax.swing.JFrame;
   import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
   import javax.swing.event.ChangeListener;
   import javax.swing.event.ChangeEvent;   
 
   public class SliderFrame extends JFrame
   {
      private final JSlider diameterJSlider; // slider to select diameter 
      private final OvalPanel myPanel = new OvalPanel(); // panel to draw circle
      private JTextArea statDisplay;  
      Color c;
      // no-argument constructor
      public SliderFrame()
      {
         super("Circle Statistics");
 
          // create panel to draw circle
         myPanel.setBackground(Color.BLUE);
      
         
         // set up JSlider to control diameter value                       
         diameterJSlider =                                                 
            new JSlider(SwingConstants.HORIZONTAL, 0, 400, 10);            
         diameterJSlider.setMajorTickSpacing(10); // create tick every 10  
         diameterJSlider.setPaintTicks(true); // paint ticks on slider     
 
         // register JSlider event listener                                
         diameterJSlider.addChangeListener(                                
            new ChangeListener() // anonymous inner class                  
            {                                                              
               // handle change in slider value                            
               @Override                                                   
               public void stateChanged(ChangeEvent e)                     
               {       
            	   
            	   statDisplay.setText("");
            	   	int diameter = myPanel.getDiameter();
            	   	double radius = myPanel.getDiameter() * .5;      
            	   	double circumference = Math.PI * diameter;
            	   	double area = Math.PI * radius * radius;
            	   	myPanel.setDiameter(diameterJSlider.getValue()); 
            	   	myPanel.setColor(1, 1, 1);
            	   	statDisplay.setBackground(Color.WHITE);
                	statDisplay.append(String.format(" Radius: %.5f%n Diameter: %d%n Circumference: %,.5f%n Area: %,.5f%n", radius, diameter, circumference,area ));
                	
               }                                                           
            }                                                              
         );                                                                
 
       	statDisplay = new JTextArea(15, 30);

        add(statDisplay, BorderLayout.NORTH); 
         add(diameterJSlider, BorderLayout.SOUTH);
         add(myPanel, BorderLayout.CENTER);
      }
   } // end class SliderFrame