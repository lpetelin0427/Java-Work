   // Fig. 22.4: SliderDemo.java
   // Testing SliderFrame.
   import javax.swing.JFrame;
 
   public class SliderDemo
   {
      public static void main(String[] args)
      {
         SliderFrame sliderFrame = new SliderFrame();
         sliderFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         sliderFrame.setSize(800, 800);
         sliderFrame.setLocationRelativeTo(null);
         
         sliderFrame.setVisible(true);
      }
   } // end class SliderDemo