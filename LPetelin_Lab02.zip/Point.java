//Luke Petelin
//Lab 01
//2 September 2017
public class Point {
	private int X;
	private int Y;

public Point(){
		X= 0;
		Y = 0;
	}
	
public Point(int newX, int newY){
	X = newX;
	Y = newY;
}
public int getX(){
	return(X);
}
public int getY(){
	return(Y);
}
public void setX(int newX){
	X = newX;
}
public void setY(int newY){
	Y = newY;
}
public String toString(){
	String thisString= "";
	thisString= "\n The X Coordinate = " + X
				+" The Y Coordinate = " + Y	;
	return(thisString);
}
}
