
public class Rectangle extends Point {
	protected int width;
	protected int length;
	
	public Rectangle(){
		super();
		width = 15;
		length = 15;
	}
	public Rectangle(int newWidth, int newLength){
		super();
		width = newWidth;
		length = newLength;
	}
	public void setWidth(int newWidth){
		width = newWidth;
	}
	public void setLength(int newLength){
		length = newLength;
	}
	public int getWidth(){
		return width;
	}
	public int getLength(){
		return length;
	}
	public int area(){
		return (width * length);
	}
	public String toString(){
		
	return super.toString() + 
			"\n Width: " + width +
			"\n Length: " + length;

	}
}
