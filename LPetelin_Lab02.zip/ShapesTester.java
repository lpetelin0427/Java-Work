//Luke Petelin
//Lab 03
//9 September 2017
public class ShapesTester {

	public static void main(String[] args) {
		System.out.println("Luke Petelin" + 
						"\nLab2 Rectangle and Box" + 
							"\n9 September 2017");
		Point point1 = new Point();
		Point point2 = new Point(5,19);
		Rectangle rectangle1 = new Rectangle();
		Rectangle rectangle2 = new Rectangle(24, 30);
		Box box1 = new Box();
		Box box2 = new Box(60);
		System.out.println("The area of Rectangle 1: " + rectangle1.area() + " square units");
		System.out.println("The area of Rectangle 2: " + rectangle2.area() + " square units");
		System.out.println("*******************************************");
		System.out.printf("%s%,d%s%n", "The area of Box 1: " , box1.area() , " square units");
		System.out.printf("%s%,d%s%n", "The volume of Box 1: " , box1.volume() , " cube units");
		System.out.println("*******************************************");
		System.out.println("Changing box 2 width to 21...");
		box2.setWidth(21);
		System.out.printf("%s%,d%s%n", "The area of Box 2: " , box2.area() , " square units");
		System.out.printf("%s%,d%s%n", "The volume of Box 2: " , box2.volume() , " cube units");
		System.out.println("*******************************************");
		
		System.out.println("Instance variables for each object");
		
		System.out.println("Point 1: " + point1.toString());
		System.out.println("Point 2: " + point2.toString());
		System.out.println("Rectangle1: " + rectangle1.toString());
		System.out.println("Rectangle2: " + rectangle2.toString());
		System.out.println("Box1: " + box1.toString());
		System.out.println("Box2: " + box2.toString());
	}

}
