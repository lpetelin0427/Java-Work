import java.awt.Color;
import java.awt.Graphics;

public class MyBox extends MyShape{
	private boolean filled;
	private static int newWidth1;
	private static int newLength1;
	public MyBox(int newWidth, int newLength){
		super();
		filled = false;
		newWidth1 = newWidth;
		newLength1 = newLength;
	}
	public MyBox(int x1, int y1, int x2, int y2, Color color, boolean filled){
		super(x1, y1, newWidth1, newLength1, color);
		this.filled = filled;
	}
	public void setFilled(boolean isFilled){
		filled = isFilled;
	}
	public int getUpperLeftX(){
		return Math.min(getX1(), getX2());
	}
	public int getUpperLeftY(){
		return Math.min(getY1(), getY2());
	}
	public int getWidth(){
		return Math.abs(getX2() - getX1());
	}
	public int getHeight(){
		return Math.abs(getY2() - getY1());
	}

	public void paintComponent(Graphics g){
		g.setColor(Color.BLUE);
		 int w,h;
		 	g.drawRect(0,0, w=newWidth1/2, h=newLength1/2);
		 	
	        g.drawRect(w/2, h/2, w/2*2, h/2*2);

	        g.drawLine(0,0,w/2,h/2);

	        g.drawLine(w,h,w/2+w/2*2,h/2+h/2*2);

	        g.drawLine(w,0,w/2+w/2*2,h/2);  

	        g.drawLine(0,h,w/2,h/2+h/2*2); 
	}


}
