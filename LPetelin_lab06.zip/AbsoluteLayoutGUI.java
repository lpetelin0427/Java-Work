import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class AbsoluteLayoutGUI extends JPanel implements ActionListener{

	JLabel titleLabel, widthLabel, heightLabel , radiusLabel ,lengthLabel, radioLabel;
	JRadioButton rectangleRadioButton, boxRadioButton, circleRadioButton, cylinderRadioButton;
	JTextField widthTextField, lengthTextField, heightTextField, radiusTextField;

	int width = 0, height = 0, radius = 0, length = 0;
	JPanel totalGUI,radioButtonPanel, widthPanel,lengthPanel, heightPanel, radiusPanel;
	JButton processButton;

	boolean isShowing = true;
		public static void main(String[] args) {
		createAndShowGUI();		
	}
	
	private static void createAndShowGUI() {
		JFrame frame = new JFrame("AbsoluteLayout GUI");
		
		AbsoluteLayoutGUI demo = new AbsoluteLayoutGUI();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(demo.createContentPane());
		frame.setSize(380, 300);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public JPanel createContentPane() {
		
		totalGUI = new JPanel();
		totalGUI.setLayout(null);
		titleLabel = new JLabel(" The Figure Center");
		Font titleFont = new Font("Verdana", Font.BOLD, 26);
		titleLabel.setFont(titleFont);
		titleLabel.setLocation(40,0);
		titleLabel.setSize(300, 60);
		
		totalGUI.add(titleLabel);
		
		radioButtonPanel = new JPanel();
		radioButtonPanel.setLayout(null);
		radioButtonPanel.setLocation(20,60);
		radioButtonPanel.setSize(100,100);
		
		rectangleRadioButton = new JRadioButton("Rectangle");
		rectangleRadioButton.setLocation(0, 20);
		rectangleRadioButton.setSize(100,20);
		rectangleRadioButton.addActionListener(this);	
		radioButtonPanel.add(rectangleRadioButton);
		
		boxRadioButton = new JRadioButton("Box");
		boxRadioButton.setLocation(0, 40);
		boxRadioButton.setSize(100,20);
		boxRadioButton.addActionListener(this);	
		radioButtonPanel.add(boxRadioButton);

		circleRadioButton = new JRadioButton("Circle");
		circleRadioButton.setLocation(0, 60);
		circleRadioButton.setSize(100,20);
		circleRadioButton.addActionListener(this);	
		radioButtonPanel.add(circleRadioButton);
		
		cylinderRadioButton = new JRadioButton("Cylinder");
		cylinderRadioButton.setLocation(0, 80);
		cylinderRadioButton.setSize(100,20);
		cylinderRadioButton.addActionListener(this);	
		radioButtonPanel.add(cylinderRadioButton);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rectangleRadioButton);
		group.add(boxRadioButton);
		group.add(circleRadioButton);
		group.add(cylinderRadioButton);
		
		radioLabel = new JLabel("Select a figure.");
		radioLabel.setSize(100,20);
		radioLabel.setLocation(0, 0);
		radioButtonPanel.add(radioLabel);
		
		totalGUI.add(radioButtonPanel);
		
		widthPanel = new JPanel();
		widthPanel.setLayout(null);
		widthPanel.setSize(100,50);
		widthPanel.setLocation(130,60);
		
		widthLabel = new JLabel("Enter width" );
		widthLabel.setSize(100, 20);
		widthLabel.setLocation(0,0);
		widthPanel.add(widthLabel);
		widthPanel.setVisible(false);
		
		widthTextField = new JTextField();
		widthTextField.setLocation(0,20);
		widthTextField.setSize(100,20);
		widthPanel.add(widthTextField);
		
		totalGUI.add(widthPanel);
		
		lengthPanel = new JPanel();
		lengthPanel.setLayout(null);
		lengthPanel.setSize(100,50);
		lengthPanel.setLocation(240,60);
		lengthPanel.setVisible(false);

		lengthLabel = new JLabel("Enter length" );
		lengthLabel.setSize(100, 20);
		lengthLabel.setLocation(0,0);
		lengthPanel.add(lengthLabel);
		
		lengthTextField = new JTextField();
		lengthTextField.setLocation(0,20);
		lengthTextField.setSize(100,20);
		lengthPanel.add(lengthTextField);
	
		totalGUI.add(lengthPanel);

		radiusPanel = new JPanel();
		radiusPanel.setLayout(null);
		radiusPanel.setSize(100,50);
		radiusPanel.setLocation(130,120);
		radiusPanel.setVisible(false);

		radiusLabel = new JLabel("Enter radius" );
		radiusLabel.setSize(100, 20);
		radiusLabel.setLocation(0, 0);
		radiusPanel.add(radiusLabel);
		
		radiusTextField = new JTextField();
		radiusTextField.setLocation(0,20);
		radiusTextField.setSize(100,20);
		radiusPanel.add(radiusTextField);
		
		totalGUI.add(radiusPanel);

		heightPanel = new JPanel();
		heightPanel.setLayout(null);
		heightPanel.setSize(100,50);
		heightPanel.setLocation(240,120);
		heightPanel.setVisible(false);

		heightLabel = new JLabel("Enter height" );
		heightLabel.setSize(100, 20);
		heightLabel.setLocation(0,0);
		heightPanel.add(heightLabel);
		
		heightTextField = new JTextField(5);
		heightTextField.setSize(100,20);
		heightTextField.setLocation(0,20);
		heightPanel.add(heightTextField);
		totalGUI.add(heightPanel);

		processButton = new JButton("Click to Process");
		processButton.setLocation(30,180);
		processButton.setSize(300,60);
		processButton.addActionListener(this);
		processButton.setVisible(false);
		
		totalGUI.add(processButton);
		
		return totalGUI;
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource() == rectangleRadioButton){
			widthPanel.setVisible(true);
			lengthPanel.setVisible(true);
			radiusPanel.setVisible(false);
			heightPanel.setVisible(false);
			processButton.setVisible(true);
	}
	else if (e.getSource() == boxRadioButton){
		widthPanel.setVisible(true);
		lengthPanel.setVisible(true);
		radiusPanel.setVisible(false);
		heightPanel.setVisible(true);
		processButton.setVisible(true);
		}
	else if (e.getSource() == circleRadioButton){
		widthPanel.setVisible(false);
		lengthPanel.setVisible(false);
		radiusPanel.setVisible(true);
		heightPanel.setVisible(false);
		processButton.setVisible(true);
		}	
	else if (e.getSource() == cylinderRadioButton){
		widthPanel.setVisible(false);
		lengthPanel.setVisible(false);
		radiusPanel.setVisible(true);
		heightPanel.setVisible(true);
		processButton.setVisible(true);
		}
	if (e.getSource() == processButton){
		//Radio Button Disables
		rectangleRadioButton.setEnabled(false);
		boxRadioButton.setEnabled(false);
		circleRadioButton.setEnabled(false);
		cylinderRadioButton.setEnabled(false);
		//Text Field Button Disables
		widthTextField.setEnabled(false);
		lengthTextField.setEnabled(false);
		radiusTextField.setEnabled(false);
		heightTextField.setEnabled(false);
		//Button Disables
		processButton.setEnabled(false);

		if(rectangleRadioButton.isSelected()){
			try{		
				width = Integer.parseInt(widthTextField.getText());
				if(width <= 0){
					widthTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				lengthTextField.setBackground(Color.red);		
			}
			try{
				length = Integer.parseInt(lengthTextField.getText());
				if(length <= 0){
					lengthTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				lengthTextField.setBackground(Color.red);
			}
			JFrame application = new JFrame("Rectangle");
			application.setSize(500,500);
			application.setLocationRelativeTo(null);
			application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyRectangle panel = new MyRectangle(width, length);
			application.add(panel);
			application.setVisible(isShowing);
		}
		if(boxRadioButton.isSelected()){
			try{		
				width = Integer.parseInt(widthTextField.getText());
				if(width <= 0){
					widthTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				lengthTextField.setBackground(Color.red);		
			}
			try{
				length = Integer.parseInt(lengthTextField.getText());
				if(length <= 0){
					lengthTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				lengthTextField.setBackground(Color.red);
			}
			try{
				height = Integer.parseInt(heightTextField.getText());
				if(height <= 0){
					heightTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				heightTextField.setBackground(Color.red);
			}
			JFrame application = new JFrame("Rectangle");
			application.setSize(500,500);
			application.setLocationRelativeTo(null);
			application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyBox panel = new MyBox(width, length);
			application.add(panel);
			application.setVisible(isShowing);
		}
		
			
		if(circleRadioButton.isSelected()){
			try{
				radius = Integer.parseInt(radiusTextField.getText());
				if(radius <= 0){
					radiusTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex){
				radiusTextField.setBackground(Color.red);	
				isShowing = false;
				}
			JFrame application = new JFrame("Rectangle");
			application.setSize(500,500);
			application.setLocationRelativeTo(null);
			application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyCircle panel = new MyCircle(radius);
			application.add(panel);
			application.setVisible(isShowing);
		}
		
		if(cylinderRadioButton.isSelected()){
			try{
				radius = Integer.parseInt(radiusTextField.getText());
				if(radius <= 0){
					radiusTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex){
				radiusTextField.setBackground(Color.red);	
				isShowing = false;
				}
			try{
				height = Integer.parseInt(heightTextField.getText());
				if(height <= 0){
					heightTextField.setBackground(Color.yellow);
					isShowing = false;
				}
			}catch (Exception ex1){
				isShowing= false;
				heightTextField.setBackground(Color.red);
			}
			JFrame application = new JFrame("Rectangle");
			application.setSize(500,500);
			application.setLocationRelativeTo(null);
			application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			MyCylinder panel = new MyCylinder(radius, height);
			application.add(panel);
			application.setVisible(isShowing);
		}
	}//processButton
	}//actionPeformed
}//class
