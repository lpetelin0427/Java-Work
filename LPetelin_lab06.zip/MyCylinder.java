import java.awt.Color;
import java.awt.Graphics;

public class MyCylinder extends MyShape {
	private boolean filled;
	private static int newRadius1;
	private static int newHeight1;

	public MyCylinder(int newRadius, int newHeight){
		super();
		filled = false;
		newRadius1 = newRadius;
		newHeight1 = newHeight;
	}
	public MyCylinder(int x1, int y1, int x2, int y2, Color color, boolean filled){
		super(x1, y1, x2, y2, color);
		this.filled = filled;
	}
	public int getUpperLeftX(){
		return Math.min(getX1(), getX2());
	}
	public int getUpperLeftY(){
		return Math.min(getY1(), getY2());
	}
	public int getWidth(){
		return Math.abs(getX2() - getX1());
	}
	public int getHeight(){
		return Math.abs(getY2() - getY1());
	}
	public boolean isFilled(){
		return filled;
	}
	public void paintComponent(Graphics g){
		g.setColor(Color.BLACK);
		int r = newRadius1 , h = newHeight1;
		   g.drawOval(50,60,100,50);     
		    g.drawLine(50,80,50,200);    
		    g.drawLine(150,80,150,200); 
		    g.drawOval(50,180,100,50);   

		  
	}
}