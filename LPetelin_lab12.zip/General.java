//Luke Petelin
//Lab 12 Sorting and Searching
//11/28/2017

import java.io.Serializable;

public class General implements Serializable

{
	private int ID;
	private String name;
	private int age;

	public General()
	{
		ID = 0;
		name = "";
		age = 0;
	}

	public General(int myID, String myName, int myAge)
	{
		ID = myID;
		name = myName;
		age = myAge;
	}

    public int getID()
 	{
 		return ID;
	}

    public String getName()
	{
		return name;
	}

	public int getAge()
	{
		return age;
	}

	public void setID(int newID)
	{
		ID = newID;
	}

	public void setName(String newName)
	{
		name = newName;
	}

	public void setAge(int newAge)
	{
		age = newAge;
	}

	public String toString()
	{
		return ("ID: " + ID + "\nName: " + name + "\nAGE: " + age);
	}
}