//Luke Petelin
//Lab 12 Sorting and Searching
//11/28/2017

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

public class GeneralRosters
{
	private ObjectInputStream input;
	private General [] roster = new General[20];



    // **** SORT ROUTINE *******
    public void sortRoster()
    {
		System.out.println("** In sortRoster **");
		//ADD SORT CODE HERE
		for(int i = 0; i < roster.length - 1; i++){
			for(int j = i + 1; j < roster.length; j++){
				if(roster[i].getID() > roster[j].getID()){
					General temp = roster[i];
					roster[i] = roster[j];
					roster[j] = temp;
				}
			}
		}
		System.out.println("\n**The Sorted Roster**\n");
		for (General sortedRoster : roster)
			System.out.println(sortedRoster.toString() + "\n");
    }
    //******* SEARCH ROUTINE *******

    public void searchRoster(){
		System.out.println("** serchRoster **");
		Scanner reader = new Scanner(System.in);
		//User should be allowed mutiple searches
		//if the target is not found you should alert
		//the user to that fact
		do{
		//ADD Search CODE HERE
		System.out.println("Please enter the general's ID that you wish to find (0 to quit)");
		int genID = reader.nextInt();
		if(genID == 0){
			System.out.println("Thank you for using my program!");
			System.exit(0);
		}
		else{
		int result = -1;
		int finalIndex = roster.length-1;
		result = search(roster, 0, finalIndex, genID);
		
		if (result >=0)
			System.out.println("**** TARGET FOUND ****\n" + roster[result].toString());
		else
			System.out.println("**** TARGET " + genID + " was not found. ****");
		}
		}while(true);
    }
    public static int search(General[] roster2, int first, int last, int key){
		int result = 0;
		
		if (first > last)
			result = -1;
		else{
			int mid = (first + last)/2;
			
			if (key == roster2[mid].getID())
				result = mid;
			else if(key < roster2[mid].getID())
				result = search(roster2, first, mid - 1, key);
			else if(key > roster2[mid].getID())
				result = search(roster2, mid + 1, last, key);
		}
		return result;
	}
    //******* OPEN FILE ROUTINE *******
    //  make sure that generalMaster.ser  is in the folder from
    //  whih your programs are running
    //  NO CHANGES ARE NEEDED IN THIS METHOD
	public void openFile(){
		System.out.println("** In openFile **");
		try
		{
			input = new ObjectInputStream(new FileInputStream("generalMaster.ser"));
	    }
	    catch(IOException ioException)
	    {
			System.err.println("can't open or accesss file  " + ioException + "\n");
	    }
	}

 //******* READ FILE and LOAD ARRAY ROUTINE *******

	public void readRecords(){
		System.out.println("** In readRecords **");
		General  record;
	    int count = 0;   //Used to populate array in while loop

		System.out.printf("%-12s%-20s%-12s\n","ID","Name","Age");
			try
			{
				while(true)
				{
					record = (General) input.readObject();
                    //ADD TWO LINES HERE TO POPULATE YOUR Roster ARRAY
					roster[count] = new General(record.getID(), record.getName(), record.getAge());
					count++;
					
					
					System.out.printf("%-12d%-20s%-12d\n",record.getID(), record.getName(), record.getAge());

		        }
	        }
		    catch(EOFException e){
				System.out.println("....catch ...." + e + "\n");
				return;
			}
			catch(ClassNotFoundException eclassNotFound){
				System.out.println("....catch ...." + eclassNotFound + "\n");
			}
			catch(IOException eIO){
				System.out.println("....catch ...." + eIO + "\n");
			}
		}

 //******* CLOSE FILE ROUTINE *******
 //  NO CHANGES ARE NEEDED IN THIS METHOD
	public void closeFile(){
		System.out.println("** In closeFile **");
		try
		{
		if (input != null)
			input.close();
		}
		catch(IOException ioExcetion)
		{
			System.err.println("Error closing file");
			System.exit(1);
		}
}
}