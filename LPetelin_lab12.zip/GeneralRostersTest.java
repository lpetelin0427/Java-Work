//Luke Petelin
//Lab 12 Sorting and Searching
//11/28/2017

public class GeneralRostersTest
{
	public static void main( String[] args )
	{
		GeneralRosters application = new GeneralRosters();

		application.openFile();

		application.readRecords();

		application.closeFile();

		application.sortRoster();

		application.searchRoster();

    }
}
