import java.util.StringTokenizer;
import java.util.Scanner;
import java.util.Random;

public class stringManipulation {

	public static void main(String[] args) {
		Random generator = new Random();
		
		String article[] = {"the ", "a " , "some " , "any "};
		String noun[] = {"dog " , "cat " , "cow ", "eagle ", "fish "};
		String verb[] =  {"drove " , "jumped " , "ran " , "walked ", "skipped ", "swam "};
		String preposition[] = {"to " , "from ", "over " , "under ", "for "};
		
		String[] sentence = new String[3];
		String[] replacedSentence = new String[3];
		for( int j = 0; j < sentence.length; j++){
			int article1 = generator.nextInt(article.length);
			int noun1 = generator.nextInt(noun.length);
			int verb1 = generator.nextInt(verb.length);
			int preposition1 = generator.nextInt(preposition.length);
			int article2 = generator.nextInt(article.length);
			int noun2 = generator.nextInt(noun.length);
			sentence[j] = Character.toUpperCase(article[article1].charAt(0)) + article[article1].substring(1) + noun[noun1] + verb[verb1]+ preposition[preposition1] + article[article2] + noun[noun2].replace(" ", ".");
			replacedSentence[j] = Character.toUpperCase(article[article1].charAt(0)) + article[article1].substring(1).replace("o", "X-X-X") + noun[noun1].replace("o", "X-X-X") + verb[verb1].replace("o", "X-X-X")+ preposition[preposition1].replace("o", "X-X-X") + article[article2].replace("o", "X-X-X") + noun[noun2].replace(" ", ".").replace("o", "X-X-X");

			System.out.println(sentence[j] + "\n");
			System.out.println(replacedSentence[j] + "\n");

		}
		System.out.println("- - - - - - - - - - ");
		System.out.println("- - - - - - - - - - ");
		System.out.println("OK let's tokenize!");
		for( int j = 0; j < sentence.length; j++){
			int article1 = generator.nextInt(article.length);
			int noun1 = generator.nextInt(noun.length);
			int verb1 = generator.nextInt(verb.length);
			int preposition1 = generator.nextInt(preposition.length);
			int article2 = generator.nextInt(article.length);
			int noun2 = generator.nextInt(noun.length);
			sentence[j] = Character.toUpperCase(article[article1].charAt(0)) + article[article1].substring(1) + noun[noun1] + verb[verb1]+ preposition[preposition1] + article[article2] + noun[noun2].replace(" ", ".");
			System.out.println("- - - - - - - - - - ");

			System.out.println("\nORIGINAL: " + sentence[j] + "\n");
			String[] tokens = sentence[j].split("o");
			System.out.println("The number of tokens is: " + tokens.length );
			int counter = 0;
			for(String s:tokens){
				System.out.println("Token " + counter + " is: " + s);
				counter++;
			}//end inner for
			
		}//end outer for




	}

}
