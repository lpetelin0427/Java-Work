
public class Artifact {
	private int artifactID;
	private String artifactName;
	private int artifactYear;
	private int acquiredYear;
	private double artifactValue;
	
	public Artifact(){
		this( 0, "ARTIFACT", 0, 0, 0.0);
		
	}
	public Artifact(int aID, String name, int artYear, int acqYear,  double value){
		setArtifactID(aID);
		setArtifactName(name);
		setArtifactYear(artYear);
		setAcquiredYear(acqYear);
		setArtifactValue(value);
	}

	public void setArtifactID(int sID){
		artifactID = sID;
	}	
	public void setArtifactName(String name){
		artifactName = name;
	}
	public void setArtifactYear(int age){
		artifactYear = age;
	}	
	public void setAcquiredYear(int acqYear){
		acquiredYear = acqYear;
	}
	public void setArtifactValue(double debt){
		artifactValue = debt;
	}	
	
	public int getArtifactID(){
		return artifactID;
	}	
	public String getArtifactName(){
		return artifactName;
	}
	public int getArtifactYear(){
		return artifactYear;
	}	
	public int getAcquiredYear(){
		return acquiredYear;
	}	
	public double getArtifactValue(){
		return artifactValue;
	}
	public String toString(){
		return("ID:		" + artifactID +
				" Name: 	" + artifactName +
				 " Artifact Year: 	" + artifactYear + 
				  " Acquired Year: 	" + acquiredYear + 
				 " Value:    " + artifactValue);
	}
}
