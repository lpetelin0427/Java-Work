
public class CreateArtifactFileTest {

	public static void main(String[] args) {
		
		CreateArtifactFile application = new CreateArtifactFile();
		
		application.openFile();
		
		application.addRecords();
		
		application.closeFile();
		
	}

}
