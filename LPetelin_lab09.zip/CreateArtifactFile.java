import java.io.FileNotFoundException;
import java.lang.SecurityException;
import java.util.Formatter;
import java.util.FormatterClosedException;

public class CreateArtifactFile {
	private Formatter output;
	
	public void openFile(){
		System.out.println("In openFile");
		try{
			output = new Formatter("ArtifactMaster.txt");
			System.out.println("File Has Been Opened");
		}catch(FileNotFoundException fileNotFoundException){
			System.err.println("Error opening or creating file");
			System.exit(1);
		}
		catch(SecurityException securityException){
			System.err.println("You do not have write acces to this file.");
			System.exit(2);
		}
		
	}//end openFile
	
	public void addRecords(){
		System.out.println("In addRecords");
		
		int[] IDArray = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		String[] nameArray = {"","Hat","Buckle","Cartridge","Stove","Harness","Wheel","TentShelter","TentOfficerWall","MapVaBullRun","Canteen", "Blanket","SurgeonTools","MapPaChambersburg","MapDC"};
		int[] artifactYearArray = {0,1856,1863,1865,1861,1861,1862,1863,1864,1865,1863,1864,1862,1864,1860};
		int[] acquiredYearArray = {0,1913,1913,1915,1918,1945,1951,1954,1969,1972,1976,1993,2013,1813,2014};
		double[] valueArray = {0,1100.10,2100.00,-1300.30,4100.00,5100.50,1600.00,1700.70,8001.00,9001.90,1011.11,1022.22,3131.33,1344.44,5500.50};
		
		Artifact[] record = new Artifact[100];
		
		for (int index = 0; index < nameArray.length; index++){
			try{
				record[index] = new Artifact();
				
				record[index].setArtifactName(nameArray[index]);
				record[index].setArtifactID(IDArray[index]);
				record[index].setArtifactYear(artifactYearArray[index]);
				record[index].setAcquiredYear(acquiredYearArray[index]);
				record[index].setArtifactValue(valueArray[index]);

				record[index] = new Artifact(IDArray[index], nameArray[index], artifactYearArray[index], acquiredYearArray[index], valueArray[index]);
				
				if(record[index].getArtifactID() > 0){
					if(record[index].getArtifactName() != ""){
						if(record[index].getArtifactYear() <= 2017){
							if(record[index].getAcquiredYear() >= 1899 || record[index].getAcquiredYear() >=  record[index].getArtifactYear()){

									if(record[index].getArtifactValue() >= 0){
						output.format("%d %s %d %d %.2f %n", record[index].getArtifactID(), record[index].getArtifactName(), record[index].getArtifactYear(), record[index].getAcquiredYear(), record[index].getArtifactValue());
						System.out.println(record[index].toString());
					}else
						System.out.println("Artifact Value is 0 or less. ID: " + record[index].getArtifactID());
					
					}else
						System.out.println("Acquired Year must be greater than or equal to the 1899 and greater than or equal to the artifact year. ID: " + record[index].getArtifactID());

					}else
						System.out.println("Artifact Year must be less than or equal to the current year. ID: " + record[index].getArtifactID());
					}else
						System.out.println("Artifact Name cannot be null, ID: " + record[index].getArtifactID());

			}else
				System.out.println("INCORRECT Artifact ID. Number must be greater than 0. ID: " + record[index].getArtifactID());
			
			
		}catch(FormatterClosedException formatterClosedException){
			System.err.println(" Error writing to file. Formatter closed");
			System.exit(13);
		}
		}
	}
	
	
	
	
	
	public void closeFile(){
		System.out.println("In closeFile");
		if(output != null)
			output.close();
	}//end closeFile
}//end class


