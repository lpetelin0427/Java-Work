import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class AbsoluteLayoutGUI extends JPanel{

	JLabel titleLabel, widthLabel, heightLabel , radiusLabel ,lengthLabel, radioLabel;
	JRadioButton rectangleRadioButton, boxRadioButton, circleRadioButton, cylinderRadioButton;
	JTextField widthTextField, lengthTextField, heightTextField, radiusTextField;

	JPanel totalGUI,radioButtonPanel, widthPanel,lengthPanel, heightPanel, radiusPanel;
	JButton processButton;
	
		public static void main(String[] args) {
		createAndShowGUI();		
	}
	
	private static void createAndShowGUI() {
		JFrame frame = new JFrame("AbsoluteLayout GUI");
		
		AbsoluteLayoutGUI demo = new AbsoluteLayoutGUI();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setContentPane(demo.createContentPane());
		frame.setSize(500, 500);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public JPanel createContentPane() {
		
		totalGUI = new JPanel();
		totalGUI.setLayout(new GridLayout(8,1));
		
		radioButtonPanel = new JPanel(new GridLayout(4,1));
		
		widthPanel = new JPanel();
		lengthPanel = new JPanel();
		radiusPanel = new JPanel();
		heightPanel = new JPanel();
		titleLabel = new JLabel(" The Figure Center");
		radioLabel = new JLabel("Select a figure.");
		titleLabel.setSize(300,100);
		radioLabel.setSize(70,30);

		Font titleFont = new Font("Verdana", Font.BOLD, 26);
		titleLabel.setFont(titleFont);
		radioButtonPanel();
		widthPanel();
		lengthPanel();
		radiusPanel();
		heightPanel();
		
		processButton = new JButton("Click to Process");
		processButton.setLocation(300,500);
		processButton.setSize(70,30);
		
		totalGUI.add(titleLabel);
		totalGUI.add(radioLabel);
		totalGUI.add(radioButtonPanel);
		totalGUI.add(widthPanel);
		totalGUI.add(lengthPanel);
		totalGUI.add(radiusPanel);
		totalGUI.add(heightPanel);
		totalGUI.add(processButton);
		
		return totalGUI;
	}
	public JPanel radioButtonPanel(){
		rectangleRadioButton = new JRadioButton("Rectangle");
		boxRadioButton = new JRadioButton("Box");
		circleRadioButton = new JRadioButton("Circle");
		cylinderRadioButton = new JRadioButton("Cylinder");
		rectangleRadioButton.setLocation(300,300);
		ButtonGroup group = new ButtonGroup();
		group.add(rectangleRadioButton);
		group.add(boxRadioButton);
		group.add(circleRadioButton);
		group.add(cylinderRadioButton);
		radioButtonPanel.add(rectangleRadioButton);
		radioButtonPanel.add(boxRadioButton);
		radioButtonPanel.add(circleRadioButton);
		radioButtonPanel.add(cylinderRadioButton);

		return radioButtonPanel;
	}
	public JPanel widthPanel(){
		widthLabel = new JLabel("Enter width" );
		widthLabel.setSize(70, 30);
		widthPanel.add(widthLabel);
		
		widthTextField = new JTextField(5);
		widthTextField.setSize(100,100);
		widthPanel.add(widthTextField);
	
		return widthPanel;
	}
	public JPanel lengthPanel(){
		lengthLabel = new JLabel("Enter length" );
		lengthLabel.setSize(70, 30);
		lengthPanel.add(lengthLabel);
		
		lengthTextField = new JTextField(5);
		lengthTextField.setSize(100,100);
		lengthPanel.add(lengthTextField);
	
		return lengthPanel;
	}
	public JPanel radiusPanel(){
		radiusLabel = new JLabel("Enter radius" );
		radiusLabel.setSize(70, 30);
		radiusPanel.add(radiusLabel);
		
		radiusTextField = new JTextField(5);
		radiusTextField.setSize(10,10);
		radiusPanel.add(radiusTextField);
	
		return radiusPanel;
	}
	public JPanel heightPanel(){
		heightLabel = new JLabel("Enter height" );
		heightLabel.setSize(70, 30);
		heightPanel.add(heightLabel);
		
		heightTextField = new JTextField(5);
		heightTextField.setSize(10,10);
		heightPanel.add(heightTextField);
	
		return heightPanel;
	}
}
