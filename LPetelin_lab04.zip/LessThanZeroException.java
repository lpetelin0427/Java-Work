//Used to throw an exception when a user inputs an integer less than or equal to 10
public class LessThanZeroException extends RuntimeException{

		public LessThanZeroException(){
			super("Input must be an integer greater than 0");
		}
	
		public LessThanZeroException(String message){
			super("\n***** " + message + " was not greater than 0");
		}
}
