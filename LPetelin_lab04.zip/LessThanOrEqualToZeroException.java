//Used to throw an exception when a user inputs an integer less than or equal to 10
public class LessThanOrEqualToZeroException extends RuntimeException{

		public LessThanOrEqualToZeroException(){
			super("Input must be an integer greater than or equal to 0");
		}
	
		public LessThanOrEqualToZeroException(String message){
			super("\n***** " + message + " was not greater than or equal to 0");
		}
}
