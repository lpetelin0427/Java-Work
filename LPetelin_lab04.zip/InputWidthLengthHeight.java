import java.util.InputMismatchException;
import java.util.Scanner;

public class InputWidthLengthHeight {

	public static void main(String[] args) {
		Scanner myInput = new Scanner(System.in);
		System.out.println("Luke Petelin\nLab04\n09 September 2017");
		
		int height = 0, length = 0 , width = 0;
		
		do{
		try{
		System.out.println("Please enter a width");
		width = myInput.nextInt();
		LessThanOrEqualToZeroException( "Width: ", width);
		LessThanZeroException( "Width: ", width);
		
		System.out.println("Please enter a length");
		length = myInput.nextInt();
		LessThanOrEqualToZeroException( "Length: ", length);
		LessThanZeroException( "Length: ", length);

		System.out.println("Please enter a height");
		height = myInput.nextInt();
		LessThanOrEqualToZeroException( "Height: ", height);
		LessThanZeroException( "Height: ", height);
		break;
		}catch(InputMismatchException ex){
			System.out.println("You must enter integers only: " + ex);
		}catch(LessThanOrEqualToZeroException ex){
			System.out.println("You must enter integers greater than 0: " + ex);
		}
		catch(LessThanZeroException ex){
			System.out.println("You must enter integers greater than 0:" + ex);
		}
			finally {
				myInput.nextLine();
		}
	}while(true);	
		System.out.println("\n***** All values have been accepted *****\n");
		System.out.printf("%n%s%.3f" , "The width to length ratio is " , (double)width / (double)length);
	}
	public static void LessThanOrEqualToZeroException(String myField, int myNumber) 
	         throws  LessThanOrEqualToZeroException{
		if (myNumber <= 0){
			myField = myField + " " + myNumber;
			throw new LessThanOrEqualToZeroException(myField);
	}
		}
	public static void LessThanZeroException( String myField, int myNumber )
            throws LessThanZeroException{
		if (myNumber < 0){
			myField = myField + " " + myNumber;
			throw new LessThanZeroException(myField);
	}
	}

}
