import java.util.Random;

public class Recursion {

	public static void main(String[] args) {
		int[] arrayOfNumbers = {9, 17, 25, 37, 49, 55, 999};
		Random rand = new Random();
		for(int i = 0; i < arrayOfNumbers.length; i++){
			int previousGuess = rand.nextInt(arrayOfNumbers[i]) + 1;
			System.out.println("Number: " + arrayOfNumbers[i] + "... First Guess: " + previousGuess + "\n");
			findTheRoot(arrayOfNumbers[i] , previousGuess);
			System.out.printf("%n%nThe square root of %d is: %.4f", arrayOfNumbers[i],findTheRoot(arrayOfNumbers[i] , previousGuess) );
			System.out.println("\n--------------------------");
		}
	}

	public static double findTheRoot(int i, double previousGuess) {
		
		double nextGuess = (previousGuess + i/previousGuess)/2;
		double currentGuess = previousGuess - nextGuess;

		 if (currentGuess < 0){
			 System.out.printf("%n	Next guess: %.4f" , nextGuess);
			 return findTheRoot(i , nextGuess);
		 }	
		 else if (currentGuess < 0.00001)
			return nextGuess;
		else {
			System.out.printf("%n	Next guess: %.4f" , nextGuess);
			return findTheRoot(i , nextGuess);
		}

	}

}
