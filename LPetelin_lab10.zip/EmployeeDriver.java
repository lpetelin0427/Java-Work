import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class EmployeeDriver {

	public static void main(String[] args) {
		List<Employee> list = new ArrayList<Employee>();
		
		list.add(new Employee("Davis", 61 , 1926));
		list.add(new Employee("Miller", 64 , 1904));
		list.add(new Employee("Rich", 62 , 1917));
		list.add(new Employee("Mingus", 63 , 1922));
		list.add(new Employee("Dorsey", 64 , 1905));
		list.add(new Employee("Tatum", 65 , 1909));
		list.add(new Employee("Shaw", 60 , 1910));
		list.add(new Employee("Basie", 65 , 1904));
		list.add(new Employee("Ellington", 65 , 1899));
		list.add(new Employee("Armstrong", 61 , 1901));
		list.add(new Employee("Beiderbecke", 61 , 1903));
		list.add(new Employee("Morton", 65 , 1890));
		
		//Un-Sorted
		System.out.println("\n\nThe UN-Sorted List\n");
		for (Employee e: list)
			System.out.println(e.getLastName() + 
					 		   " " + e.getGroupID() + 
					 		   " " + e.getID());	
		
		//Sort
		Collections.sort(list, new EmployeeGroupComparator()); 
		
		System.out.println("\nThe Sorted List(Group ID\n");
		for (Employee e: list)
			System.out.println(e.getLastName() + 
					 		   " " + e.getGroupID() + 
					 		   " " + e.getID());
		//Shuffled
		Collections.shuffle(list);
		System.out.println("\nThe Shuffled List\n");
		for (Employee e: list)
			System.out.println(e.getLastName() + 
					 		   " " + e.getGroupID() + 
					 		   " " + e.getID());
		//Reverse
		Collections.reverse(list);
		System.out.println("\nThe Reversed List\n");
		for (Employee e: list)
			System.out.println(e.getLastName() + 
					 		   " " + e.getGroupID() + 
					 		   " " + e.getID());
		
		//Sorted Last Name
		Collections.sort(list, new EmployeeLastNameComparator()); 
		System.out.println("\nThe Sorted List(Last Name)\n");
		for (Employee e: list)
			System.out.println(e.getLastName() + 
					 		   " " + e.getGroupID() + 
					 		   " " + e.getID());
		
		//Sorted Last Name with Iterator
		System.out.println("\nThe Sorted List(Last Name) with Iterator\n");
		ListIterator<Employee> listIt = list.listIterator();
		while(listIt.hasNext()){
			System.out.println(listIt.next());
		}
		
		//Sorted Last Name with Iterator
		System.out.println("\nThe Sorted List(Last Name) with Iterator REVERSE\n");
				while(listIt.hasPrevious()){
					System.out.println(listIt.previous());
				}
				
		System.out.println("\nThanks for sorting your Employees!");
	}

}
