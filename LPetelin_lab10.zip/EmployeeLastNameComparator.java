import java.util.Comparator;

public class EmployeeLastNameComparator implements Comparator<Employee>{
	public int compare (Employee lastNameA, Employee lastNameB){
		
	        return lastNameA.getLastName().compareToIgnoreCase(lastNameB.getLastName());
	}   
}
