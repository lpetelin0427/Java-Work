import java.util.Comparator;

public class EmployeeGroupComparator implements Comparator<Employee>{
	
	public int compare (Employee groupIDA, Employee groupIDB){
		
		int groupIDCompare = groupIDA.getGroupID() - groupIDB.getGroupID();
		
		if (groupIDCompare != 0)
			return groupIDCompare;
		
		int iDCompare = groupIDA.getID() - groupIDB.getID();
		
		return iDCompare;
	}
}
