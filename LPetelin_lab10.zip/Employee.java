
public class Employee {
	private String lastName;
	private int groupID;
	private int ID;
	
	
	public Employee(){
		setLastName(null);
		setGroupID(0);
		setID(0);
	}
	
	public Employee(String myLastName, int myGroupID, int myID){
		setLastName(myLastName);
		setGroupID(myGroupID);
		setID(myID);
	}

	public String getLastName(){
		return lastName;
	}
	public int getGroupID(){
		return groupID;
	}
	public int getID(){
		return ID;
	}
	public void setLastName(String newLastName){
		lastName = newLastName;
	}
	public void setGroupID(int newGroupID){
		groupID = newGroupID;
	}
	public void setID(int newID){
		ID = newID;
	}


	public String toString(){
		return ("\n *****\n\nGroup ID: " + groupID + 
				 "\n ID: " + ID +
				  "\n Last Name: " + lastName + "\n");		 
	}


}
