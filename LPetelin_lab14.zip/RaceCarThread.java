import java.util.Random;

public class RaceCarThread extends Thread{
	private static Boolean raceNow;
	private double lapsCompleted;
	
	public RaceCarThread(String name){
		super(name);
		raceNow = true;
		lapsCompleted = 0;
	}
	public RaceCarThread(){
		super();
		raceNow = true;
		lapsCompleted = 0;
	}
	public void run(){
		Random ranGen = new Random();
		do{
			try{	
				lapsCompleted += ranGen.nextDouble() % 1;
				 if(getName().equals("Corvette")){
						if(lapsCompleted >= 15){
							System.out.println("\n*********************");
							System.out.println(getName() + " is the winner!");
							raceNow = false;
						break;
						}
						System.out.printf("%s on Lap: # %.2f%n" , getName(), lapsCompleted);
					Thread.sleep(250);
				}	
				else if(getName().equals("Ferrari")){
					if(lapsCompleted >= 15){
						System.out.println("\n*********************");
						System.out.println(getName() + " is the winner!");
						raceNow = false;
						break;
					}
					System.out.printf("%s on Lap: # %.2f%n" , getName(), lapsCompleted);
					Thread.sleep(240);
				}
				else if(getName().equals("Viper")){
					if(lapsCompleted >= 15){
						System.out.println("\n*********************");
						System.out.println(getName() + " is the winner!");
						raceNow = false;
						break;
					}
					System.out.printf("%s on Lap: # %.2f%n" , getName(), lapsCompleted);
					Thread.sleep(230);
				}
				else if(getName().equals("Audi")){
					if(lapsCompleted >= 15){
						System.out.println("\n*********************");
						System.out.println(getName() + " is the winner!");
						raceNow = false;
						break;
					}
					System.out.printf("%s on Lap: # %.2f%n" , getName(), lapsCompleted);
					Thread.sleep(220);
				}
				else if(getName().equals("Porsche")){
					if(lapsCompleted >= 15){
						System.out.println("\n*********************");
						System.out.println(getName() + " is the winner!");
						raceNow = false;
						break;
					}
					System.out.printf("%s on Lap: # %.2f%n" , getName(), lapsCompleted);
					Thread.sleep(210);
					System.out.println("\n*********************");
				}

			}catch(InterruptedException e){
				System.out.println("Can't lap, car crashed. " + e);
			}

		}while(raceNow);
	}
}
