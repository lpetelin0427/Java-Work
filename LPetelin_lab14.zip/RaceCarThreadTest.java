
public class RaceCarThreadTest {

	public static void main(String[] args) {
		RaceCarThread corvette, ferarri, viper, audi, porsche;
		
		corvette = new RaceCarThread("Corvette");
		ferarri = new RaceCarThread("Ferarri");
		viper = new RaceCarThread("Viper");
		audi = new RaceCarThread("Audi");
		porsche = new RaceCarThread("Porsche");

		corvette.start();
		ferarri.start();
		viper.start();
		audi.start();
		porsche.start();
		
	}

}
